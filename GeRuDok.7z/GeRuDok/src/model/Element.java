/***********************************************************************
 * Module:  Element.java
 * Author:  Ognjen
 * Purpose: Defines the Class Element
 ***********************************************************************/

package model;

import java.util.*;

/** @pdOid 328723e1-05ca-41dc-b721-a3bcaff3e342 */
public abstract class Element {
}