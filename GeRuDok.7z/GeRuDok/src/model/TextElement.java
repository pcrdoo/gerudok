/***********************************************************************
 * Module:  TextElement.java
 * Author:  Ognjen
 * Purpose: Defines the Class TextElement
 ***********************************************************************/

package model;

import java.util.*;

/** @pdOid 7be85156-09fc-4a5e-8135-a23816e01bde */
public class TextElement extends Element {
}