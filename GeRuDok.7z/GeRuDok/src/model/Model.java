
package model;

import java.util.*;

public class Model extends Observable {
	public Workspace workspace;
	
}